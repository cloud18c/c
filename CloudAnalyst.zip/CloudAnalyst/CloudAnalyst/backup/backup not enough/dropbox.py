import dropbox

# -------------------------
# 1. Your Dropbox Access Token
# -------------------------
ACCESS_TOKEN = "YOUR_DROPBOX_ACCESS_TOKEN_HERE"  # replace with your token
dbx = dropbox.Dropbox(ACCESS_TOKEN)

# -------------------------
# 2. Upload a file to Dropbox
# -------------------------
def upload_file(local_path, dropbox_path=None):
    """
    Uploads a local file to Dropbox
    :param local_path: path of local file to upload
    :param dropbox_path: path in Dropbox (default same as filename)
    """
    if dropbox_path is None:
        dropbox_path = '/' + local_path.split('/')[-1]
    try:
        with open(local_path, 'rb') as f:
            dbx.files_upload(f.read(), dropbox_path, mode=dropbox.files.WriteMode.overwrite)
        print(f"✅ Uploaded '{local_path}' to Dropbox as '{dropbox_path}'")
    except Exception as e:
        print("❌ Upload failed:", e)

# -------------------------
# 3. List all files in Dropbox
# -------------------------
def list_files(folder_path=''):
    """
    Lists all files in Dropbox folder
    :param folder_path: folder in Dropbox (default root)
    """
    try:
        files = dbx.files_list_folder(folder_path).entries
        print("📂 Files in Dropbox:")
        for f in files:
            print("-", f.name)
        return [f.name for f in files]
    except Exception as e:
        print("❌ Could not list files:", e)
        return []

# -------------------------
# 4. Generate Download Link
# -------------------------
def get_download_link(filename):
    """
    Generates a Dropbox download link for a file
    :param filename: filename in Dropbox
    """
    try:
        link = dbx.sharing_create_shared_link_with_settings('/' + filename)
        # Modify link for direct download
        download_url = link.url.replace("?dl=0", "?dl=1")
        print(f"🔗 Download link for '{filename}': {download_url}")
        return download_url
    except Exception as e:
        print("❌ Could not create download link:", e)
        return None

# -------------------------
# 5. Example Usage
# -------------------------
if __name__ == "__main__":
    # Upload file
    upload_file("example.txt")  # replace with your local file path

    # List files
    list_files()

    # Get download link
    get_download_link("example.txt")  # replace with Dropbox filename
