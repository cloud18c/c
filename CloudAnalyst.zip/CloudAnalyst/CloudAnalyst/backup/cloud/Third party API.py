1) Fact API

import requests

url = "https://catfact.ninja/fact" 
r = requests.get(url)
data = r.json()
print(data["fact"])



2) Weather API

import requests

city = "Chennai"  # change city name
url = f"https://wttr.in/{city}?format=j1"
r = requests.get(url)
data = r.json()
print(f" Weather in {city}: {data['current_condition'][0]['temp_C']}°C, {data['current_condition'][0]['weatherDesc'][0]['value']}")




3) Random-Joke API

import requests

url = "https://official-joke-api.appspot.com/random_joke"
r = requests.get(url)
data = r.json()
print("Joke:", data["setup"])
print("Punchline:", data["punchline"])




4) Advice API

import requests

url = "https://api.adviceslip.com/advice"
r = requests.get(url)
data = r.json()
print("Advice:", data["slip"]["advice"])




5) Random Quotes API

import requests

url = "https://api.quotable.io/random"
r = requests.get(url)
data = r.json()
print(f" \"{data['content']}\" — {data['author']}")


