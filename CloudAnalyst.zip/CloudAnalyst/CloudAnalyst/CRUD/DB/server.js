const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public")); 
const uri = process.env.MONGO_URI;
const client = new MongoClient(uri);
let tasksCollection;
async function connectDB() {
  await client.connect();
  const db = client.db("ToDoApp");
  tasksCollection = db.collection("tasks");
  console.log("Connected to MongoDB Atlas");
}
connectDB();
app.get("/tasks", async (req, res) => {
  const tasks = await tasksCollection.find().toArray();
  res.json(tasks);
});
app.post("/tasks", async (req, res) => {
  const newTask = { title: req.body.title, status: "pending" };
  await tasksCollection.insertOne(newTask);
  res.json({ message: "Task added!" });
});
app.put("/tasks/:id", async (req, res) => {
  const { id } = req.params;
  await tasksCollection.updateOne(
    { _id: new ObjectId(id) },
    { $set: { status: "completed" } }
  );
  res.json({ message: "Task updated!" });
});
app.delete("/tasks/:id", async (req, res) => {
  const { id } = req.params;
  await tasksCollection.deleteOne({ _id: new ObjectId(id) });
  res.json({ message: "Task deleted!" });
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
