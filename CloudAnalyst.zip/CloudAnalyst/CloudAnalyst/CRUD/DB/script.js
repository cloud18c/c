const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

// 🟢 Fetch all tasks
async function fetchTasks() {
  const res = await fetch("/tasks");
  const tasks = await res.json();
  taskList.innerHTML = "";
  tasks.forEach(task => {
    const li = document.createElement("li");
    li.className = task.status === "completed" ? "completed" : "";
    li.innerHTML = `
      ${task.title} - <b>${task.status}</b>
      ${task.status === "pending" ? `<button onclick="completeTask('${task._id}')">✅ Complete</button>` : ""}
      <button onclick="deleteTask('${task._id}')">❌ Delete</button>
    `;
    taskList.appendChild(li);
  });
}

// 🟢 Add Task
taskForm.addEventListener("submit", async e => {
  e.preventDefault();
  if (!taskInput.value.trim()) return;
  await fetch("/tasks", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: taskInput.value })
  });
  taskInput.value = "";
  fetchTasks();
});

// 🟡 Complete Task
async function completeTask(id) {
  await fetch(`/tasks/${id}`, { method: "PUT" });
  fetchTasks();
}

// 🔴 Delete Task
async function deleteTask(id) {
  await fetch(`/tasks/${id}`, { method: "DELETE" });
  fetchTasks();
}

// Load Tasks
fetchTasks();
