import React, { useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";

function App() {
  const { loginWithRedirect, logout, user, isAuthenticated, isLoading } = useAuth0();
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState("");

  const addTask = () => {
    if (input.trim()) {
      setTasks([...tasks, input]);
      setInput("");
    }
  };

  const deleteTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  if (isLoading) return <h2>Loading...</h2>;

  return (
    <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
      {!isAuthenticated ? (
        <>
          <h1>TaskMaster</h1>
          <button onClick={loginWithRedirect}>Log In</button>
        </>
      ) : (
        <>
          <h2>Hello, {user.name}</h2>
          <button onClick={() => logout({ logoutParams: { returnTo: window.location.origin } })}>
            Log Out
          </button>

          <h3>To-Do List</h3>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter a task"
          />
          <button onClick={addTask}>Add</button>
          <ul>
            {tasks.map((task, i) => (
              <li key={i}>
                {task} <button onClick={() => deleteTask(i)}>X</button>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

export default App;
