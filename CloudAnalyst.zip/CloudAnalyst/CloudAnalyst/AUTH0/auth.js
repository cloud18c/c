import React from "react";
import { useAuth0 } from "@auth0/auth0-react";
import "./App.css";

function App() {
  const { loginWithRedirect, logout, user, isAuthenticated } = useAuth0();

  return (
    <div style={{ textAlign: "center", marginTop: "20%" }}>
      {!isAuthenticated ? (
        <>
          <h1>Welcome to My App</h1>
          <button
            className="btn"
            style={{ marginTop: "20px", padding: "10px 20px" }}
            onClick={() => loginWithRedirect()}
          >
            Log In
          </button>
        </>
      ) : (
        <>
          <h1>Hello, {user.name}!</h1>
          <p>You are now logged in.</p>
          <button
            className="btn"
            style={{ marginTop: "20px", padding: "10px 20px" }}
            onClick={() =>
              logout({ logoutParams: { returnTo: window.location.origin } })
            }
          >
            Log Out
          </button>
        </>
      )}
    </div>
  );
}

export default App;

//index.js

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { Auth0Provider } from "@auth0/auth0-react";

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <Auth0Provider
    domain="dev-arulkaarthikeyanit.us.auth0.com"
    clientId="AFBJNv9nctbIeFuFYfmDWeEiFrlDrabA"
    authorizationParams={{
      redirect_uri: window.location.origin,
    }}
  >
    <App />
  </Auth0Provider>
);