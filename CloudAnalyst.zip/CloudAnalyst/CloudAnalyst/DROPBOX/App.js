import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const API_URL = "http://localhost:5000";

  // Fetch all files
  const fetchFiles = async () => {
    const res = await axios.get(`${API_URL}/files`);
    setFiles(res.data);
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  // Upload file
  const handleUpload = async (e) => {
    e.preventDefault();
    if (!selectedFile) return alert("Please choose a file first.");

    await axios.post(`${API_URL}/upload`, selectedFile, {
      headers: {
        "Content-Type": "application/octet-stream",
        filename: selectedFile.name,
      },
    });
    alert("File uploaded successfully!");
    fetchFiles();
  };

  // Download file
  const handleDownload = (name) => {
    window.open(`${API_URL}/download/${name}`, "_blank");
  };

  // Delete file
  const handleDelete = async (name) => {
    await axios.delete(`${API_URL}/delete/${name}`);
    alert("File deleted!");
    fetchFiles();
  };

  return (
    <div className="App">
      <h1>Dropbox File Manager</h1>

      <form onSubmit={handleUpload} className="upload-form">
        <input type="file" onChange={(e) => setSelectedFile(e.target.files[0])} />
        <button type="submit">Upload</button>
      </form>

      <h2>Available Files</h2>
      {files.length === 0 ? (
        <p>No files found.</p>
      ) : (
        <ul className="file-list">
          {files.map((file, index) => (
            <li key={index} className="file-item">
              <span>{file.name}</span>
              <div className="actions">
                <button onClick={() => handleDownload(file.name)}>Download</button>
                <button onClick={() => handleDelete(file.name)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;