const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const { Dropbox } = require("dropbox");
const fs = require("fs");
const fetch = require("isomorphic-fetch"); // Dropbox SDK needs fetch

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());
const PORT = process.env.PORT || 5000;

// Dropbox SDK setup
const dbx = new Dropbox({ accessToken: process.env.DROPBOX_ACCESS_TOKEN, fetch });


app.get("/files", async (req, res) => {
  try {
    const response = await dbx.filesListFolder({ path: "" });
    const files = response.result.entries.map((file) => ({
      name: file.name,
      path: file.path_lower,
    }));
    res.json(files);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


app.post("/upload", express.raw({ type: "application/octet-stream", limit: "50mb" }), async (req, res) => {
  const filename = req.headers["filename"];
  try {
    await dbx.filesUpload({ path: `/${filename}`, contents: req.body, mode: "overwrite" });
    res.json({ message: "File uploaded successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


app.get("/download/:name", async (req, res) => {
  const fileName = req.params.name;
  try {
    const response = await dbx.filesDownload({ path: `/${fileName}` });
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.send(response.result.fileBinary);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


app.delete("/delete/:name", async (req, res) => {
  const fileName = req.params.name;
  try {
    await dbx.filesDeleteV2({ path: `/${fileName}` });
    res.json({ message: "File deleted successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));